# Scripts de utilidad
