"""
Application layer para autenticación.
"""
