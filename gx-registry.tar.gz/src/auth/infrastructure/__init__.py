"""
Infrastructure layer para autenticación.
"""
