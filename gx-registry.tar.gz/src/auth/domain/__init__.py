"""
Domain layer para autenticación.
"""
