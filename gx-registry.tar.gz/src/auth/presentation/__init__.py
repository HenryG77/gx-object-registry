"""
Presentation layer para autenticación.
"""
